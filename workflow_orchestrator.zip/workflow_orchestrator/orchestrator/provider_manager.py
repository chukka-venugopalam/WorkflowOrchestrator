"""Provider Manager — facade and management for all AI Providers.

Connects ProviderRegistry, ProviderRuntime, ProviderDetector,
ProviderConfiguration, and CredentialManager.

Supports:
- Claude
- ChatGPT
- Gemini
- OpenAI Codex
- Cursor
- GitHub Copilot
- Claude Code
- FreeBuff
- OpenCode
- Codex CLI
- Future providers
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from workflow_orchestrator.integrations.provider_detector import ProviderDetector, DetectedProvider
from workflow_orchestrator.integrations.provider_configuration import ProviderConfiguration
from workflow_orchestrator.integrations.credential_manager import CredentialManager
from workflow_orchestrator.runtime.provider_runtime import ProviderRuntime

logger = logging.getLogger(__name__)


@dataclass
class ProviderMetadata:
    """Rich provider metadata and capability state."""

    name: str
    provider_id: str
    enabled: bool = True
    priority: int = 10
    cost: str = "medium"
    quality: str = "high"
    speed: str = "fast"
    preferred_transport: str = "rest_api"
    api_key_configured: bool = False
    cli_path: Optional[str] = None
    browser_login: bool = False
    desktop_login: bool = False
    mcp_enabled: bool = False
    health: str = "healthy"
    version: str = "1.0.0"
    status: str = "available"
    authentication_type: str = "api_key"
    unavailable_reason: str = ""


class ProviderManager:
    """Unified Orchestration Manager for AI Providers.

    Composes existing integrations and runtime services.
    """

    KNOWN_PROVIDERS = [
        "claude",
        "chatgpt",
        "gemini",
        "openrouter",
        "ollama",
        "azure_openai",
        "openai_codex",
        "cursor",
        "github_copilot",
        "claude_code",
        "freebuff",
        "opencode",
        "codex_cli",
        "continue",
        "antigravity",
        "deepseek",
    ]

    PROVIDER_ID_MAP: Dict[str, List[str]] = {
        "claude": ["anthropic.claude", "claude"],
        "chatgpt": ["openai.chatgpt", "chatgpt"],
        "gemini": ["google.gemini", "gemini"],
        "openrouter": ["openrouter", "openrouter.api"],
        "ollama": ["ollama", "ollama.local"],
        "azure_openai": ["azure.openai", "azure_openai"],
        "openai_codex": ["openai.codex", "codex"],
        "cursor": ["cursor"],
        "github_copilot": ["github.copilot", "github_copilot"],
        "claude_code": ["anthropic.claude", "claude_code"],
        "freebuff": ["freebuff"],
        "opencode": ["opencode"],
        "codex_cli": ["codex", "codex_cli"],
        "continue": ["continue"],
        "antigravity": ["antigravity"],
        "deepseek": ["deepseek"],
    }

    def __init__(
        self,
        provider_detector: Optional[ProviderDetector] = None,
        provider_config: Optional[ProviderConfiguration] = None,
        credential_manager: Optional[CredentialManager] = None,
        provider_runtime: Optional[ProviderRuntime] = None,
    ) -> None:
        self.detector = provider_detector or ProviderDetector()
        self.config_mgr = provider_config or ProviderConfiguration()
        self.cred_mgr = credential_manager or CredentialManager()
        self.runtime = provider_runtime or ProviderRuntime()

    def discover_and_load(self) -> List[ProviderMetadata]:
        """Discover installed providers and load their current status."""
        detected = self.detector.detect_all()
        detected_map: Dict[str, DetectedProvider] = {}
        for p in detected:
            if p.provider_id not in detected_map or (p.available and not detected_map[p.provider_id].available):
                detected_map[p.provider_id] = p
            if "." in p.provider_id:
                short_k = p.provider_id.split(".")[-1]
                if short_k not in detected_map or (p.available and not detected_map[short_k].available):
                    detected_map[short_k] = p

        results: List[ProviderMetadata] = []

        for pid in self.KNOWN_PROVIDERS:
            det = None
            for candidate in self.PROVIDER_ID_MAP.get(pid, [pid]):
                if candidate in detected_map:
                    det = detected_map[candidate]
                    break

            has_key = self.cred_mgr.has_api_key(f"{pid.upper()}_API_KEY") or self.cred_mgr.has_api_key(f"{pid.upper()}_KEY")
            cfg = self.config_mgr.read(pid) or {}
            cli_p = getattr(det, "cli_path", getattr(det, "path", None)) if det else cfg.get("cli_path")

            is_avail = (det and getattr(det, "available", False)) or has_key
            unavail_reason = "" if is_avail else (
                getattr(det, "unavailable_reason", "") or f"'{pid}' executable or API key not detected"
            )

            meta = ProviderMetadata(
                name=cfg.get("name", pid.replace("_", " ").title()),
                provider_id=pid,
                enabled=cfg.get("enabled", True),
                priority=cfg.get("priority", 10),
                cost=cfg.get("cost", "medium"),
                quality=cfg.get("quality", "high"),
                speed=cfg.get("speed", "fast"),
                preferred_transport=getattr(det, "transport", cfg.get("transport", "rest_api")) if det else cfg.get("transport", "rest_api"),
                api_key_configured=has_key,
                cli_path=cli_p,
                browser_login=getattr(det, "browser_login", False) if det else False,
                desktop_login=getattr(det, "desktop_login", False) if det else False,
                mcp_enabled=cfg.get("mcp_enabled", False),
                health="healthy" if is_avail else "unknown",
                version=getattr(det, "version", "1.0.0") if det else cfg.get("version", "1.0.0"),
                status="available" if is_avail else "unconfigured",
                authentication_type="api_key" if has_key else ("cli" if cli_p else "none"),
                unavailable_reason=unavail_reason,
            )
            results.append(meta)

        return results

        return results

    def get_provider(self, provider_id: str) -> Optional[ProviderMetadata]:
        """Get provider metadata by ID."""
        providers = self.discover_and_load()
        for p in providers:
            if p.provider_id.lower() == provider_id.lower() or p.name.lower() == provider_id.lower():
                return p
        return None

    def enable_provider(self, provider_id: str) -> bool:
        """Enable a provider."""
        cfg = self.config_mgr.read(provider_id) or {"name": provider_id.title(), "provider_id": provider_id}
        cfg["enabled"] = True
        return self.config_mgr.write(provider_id, cfg)

    def disable_provider(self, provider_id: str) -> bool:
        """Disable a provider."""
        cfg = self.config_mgr.read(provider_id) or {"name": provider_id.title(), "provider_id": provider_id}
        cfg["enabled"] = False
        return self.config_mgr.write(provider_id, cfg)

    def configure_provider(self, provider_id: str, api_key: Optional[str] = None, **kwargs: Any) -> bool:
        """Set configuration and API key for a provider."""
        if api_key:
            key_name = f"{provider_id.upper()}_API_KEY"
            self.cred_mgr.set_api_key(key_name, api_key)

        cfg = self.config_mgr.read(provider_id) or {"name": provider_id.title(), "provider_id": provider_id}
        for k, v in kwargs.items():
            cfg[k] = v
        return self.config_mgr.write(provider_id, cfg)

    def list_enabled(self) -> List[ProviderMetadata]:
        """Return all enabled providers."""
        return [p for p in self.discover_and_load() if p.enabled]

    def invoke_provider(self, provider_id: str, prompt: str, timeout_seconds: float = 60.0) -> str:
        """Ask a real installed desktop AI (CLI/browser/app) to respond to a
        prompt using the desktop transport layer. Raises on failure — callers decide fallback."""
        # 1. Lookup detected provider from detector
        detected_providers = self.detector.detect_all()
        det = None
        for p in detected_providers:
            if p.provider_id.lower() == provider_id.lower() or p.name.lower() == provider_id.lower():
                det = p
                break
            if "." in p.provider_id and p.provider_id.split(".")[-1].lower() == provider_id.lower():
                det = p
                break

        if not det or not det.available:
            reason = getattr(det, "unavailable_reason", "") or f"Provider '{provider_id}' is not installed or available on local system."
            raise RuntimeError(f"Provider '{provider_id}' is not available: {reason}")

        transport = (det.transport or "").lower()

        # 2. Handle CLI transport
        if transport == "cli":
            from workflow_orchestrator.integrations.transports.desktop_terminal_transport import DesktopTerminalTransport
            executable = det.path or provider_id
            term_transport = DesktopTerminalTransport(executable_name=executable)
            output = term_transport.send_prompt(prompt, timeout_seconds=timeout_seconds)
            if not output or output.strip().startswith(("Error", "Failed", "[Error]")):
                raise RuntimeError(output or f"CLI transport '{executable}' returned empty/error output")
            return output

        # 3. Handle Browser transport
        elif transport == "browser":
            from workflow_orchestrator.integrations.transports.desktop_browser_transport import DesktopBrowserTransport
            browser_transport = DesktopBrowserTransport(portal_name=provider_id)
            if not browser_transport.is_available():
                raise RuntimeError(f"Playwright browser transport not installed for '{provider_id}'")
            output = browser_transport.send_prompt(prompt)
            if not output or output.strip().startswith(("Error", "Failed", "[Error]")):
                raise RuntimeError(output or f"Browser transport '{provider_id}' returned empty/error output")
            return output

        # 4. Handle Desktop GUI app transport
        elif transport == "desktop":
            from workflow_orchestrator.integrations.transports.desktop_ui_transport import DesktopUITransport
            target_title = det.name or provider_id
            ui_transport = DesktopUITransport(target_window_title=target_title)
            captured_text, metadata = ui_transport.capture_response(prompt, timeout_seconds=timeout_seconds)
            if not captured_text or not captured_text.strip():
                raise RuntimeError(f"Desktop GUI capture for '{provider_id}' returned empty text")
            logger.info("Successfully captured response from desktop GUI app '%s' via %s", provider_id, metadata.get("capture_method"))
            return captured_text

        else:
            raise RuntimeError(f"Unsupported provider transport type '{transport}' for provider '{provider_id}'")
