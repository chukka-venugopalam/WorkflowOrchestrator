"""Automated Project Flow Engine — single-prompt AI Operating System lifecycle.

Orchestrates end-to-end project execution:
Goal Analysis
↓
Requirement Extraction
↓
Project Classification
↓
Architecture Generation
↓
Project Contract
↓
Roadmap
↓
Workflow Generation
↓
Task Graph
↓
Provider Selection
↓
Agent Selection
↓
Execution Plan
↓
Confirmation
↓
Execution
↓
Verification
↓
Deployment
↓
Project Memory
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from workflow_orchestrator.builder.project_builder import ProjectBuilder
from workflow_orchestrator.builder.data_models import BuilderConfig
from workflow_orchestrator.decision.decision_engine import DecisionEngine
from workflow_orchestrator.context.context_engine import ContextEngine
from workflow_orchestrator.knowledge.knowledge_base import KnowledgeBase
from workflow_orchestrator.contracts.contract_manager import ContractManager
from workflow_orchestrator.runtime.session_runtime import SessionManager
from workflow_orchestrator.runtime.artifact_runtime import ArtifactRuntime
from workflow_orchestrator.runtime.project_memory import ProjectMemory
from workflow_orchestrator.execution.execution_engine import ExecutionEngine
from workflow_orchestrator.core.event_bus import Event, EventBus

from workflow_orchestrator.execution.parallel_task_queue import ParallelTaskQueue, TaskProgressState

logger = logging.getLogger(__name__)


@dataclass
class FlowExecutionRecord:
    """Record of an orchestrated project flow execution."""

    project_name: str
    idea_description: str
    phase: str
    build_result: Optional[BuildResult] = None
    duration_seconds: float = 0.0
    status: str = "completed"
    error: Optional[str] = None
    failed_tasks: List[str] = field(default_factory=list)
    succeeded_tasks: List[str] = field(default_factory=list)


class ProjectFlowEngine:
    """Automates project creation, compilation, routing, execution, and memory storage."""

    def __init__(
        self,
        project_builder: Optional[ProjectBuilder] = None,
        decision_engine: Optional[DecisionEngine] = None,
        context_engine: Optional[ContextEngine] = None,
        knowledge_base: Optional[KnowledgeBase] = None,
        contract_manager: Optional[ContractManager] = None,
        session_manager: Optional[SessionManager] = None,
        project_memory: Optional[ProjectMemory] = None,
        event_bus: Optional[EventBus] = None,
    ) -> None:
        self.builder = project_builder or ProjectBuilder(event_bus=event_bus)
        self.decision_engine = decision_engine or DecisionEngine()
        self.context_engine = context_engine or ContextEngine()
        self.knowledge_base = knowledge_base or KnowledgeBase()
        self.contract_mgr = contract_manager or ContractManager()
        self.session_mgr = session_manager or SessionManager()
        self.project_memory = project_memory or ProjectMemory(project_dir=Path.cwd())
        self.event_bus = event_bus

    def execute_project_from_prompt(
        self,
        idea: str,
        project_name: Optional[str] = None,
        workspace_dir: Optional[str | Path] = None,
        auto_confirm: bool = True,
        prompt_user_fn: Any = None,
    ) -> FlowExecutionRecord:
        """Execute the full 16-phase automated project lifecycle from a text prompt.

        Args:
            idea: High-level text description of the desired application.
            project_name: Optional explicit project name.
            workspace_dir: Target output directory.
            auto_confirm: If True, executes without manual pausing.
            prompt_user_fn: Optional user clarification callback when classification is ambiguous.

        Returns:
            FlowExecutionRecord detailing the build and execution outcomes.
        """
        start_time = time.time()
        self._emit_event("project.flow.started", {"idea": idea, "project_name": project_name})

        try:
            # Step 1: Initialize session
            session = self.session_mgr.create_session(project=project_name, metadata={"goal": idea})
            self._emit_event("session.created", {"session_id": session.session_id})

            # Step 2: Invoke Builder pipeline & Real Parallel Desktop Worker Task Queue
            if workspace_dir:
                target = Path(workspace_dir).expanduser().resolve()
            else:
                from workflow_orchestrator.config.config_manager import ConfigurationManager
                output_root = ConfigurationManager().get_project_output_root()
                folder_name = project_name or f"project_{int(time.time())}"
                target = output_root / folder_name

            target.mkdir(parents=True, exist_ok=True)
            config = BuilderConfig(project_root=target)

            build_result: Dict[str, Any] = self.builder.build(
                idea=idea,
                project_name=project_name or "",
                project_root=target,
                prompt_user_fn=prompt_user_fn,
            )

            # CEO Orchestrator Multi-Worker Task Dispatch & Verification
            from workflow_orchestrator.execution.parallel_task_queue import ParallelTaskQueue
            from workflow_orchestrator.orchestrator.orchestrator import Orchestrator

            worker_registry = Orchestrator.get_instance().worker_registry
            task_scale = build_result.get("project_scale", "standard")
            task_queue = ParallelTaskQueue(worker_registry=worker_registry, project_scale=task_scale)

            # Queue DAG Nodes with skill requirements
            t1 = task_queue.add_task(
                task_id="task_backend",
                title="Build Backend API",
                required_skill="backend_api",
                prompt=f"Build Backend API endpoints for: {idea}",
            )
            t2 = task_queue.add_task(
                task_id="task_frontend",
                title="Build Frontend UI",
                required_skill="frontend_ui",
                prompt=f"Build Frontend UI components for: {idea}",
                dependencies=["task_backend"],
            )
            t3 = task_queue.add_task(
                task_id="task_tests",
                title="Build Unit Tests",
                required_skill="unit_testing",
                prompt=f"Create Unit Tests for: {idea}",
                dependencies=["task_backend"],
            )
            t4 = task_queue.add_task(
                task_id="task_deployment",
                title="Build Deployment Package",
                required_skill="deployment",
                prompt=f"Generate Docker & Deployment scripts for: {idea}",
                dependencies=["task_frontend", "task_tests"],
            )

            # Execute real desktop worker orchestration queue
            queue_results = task_queue.execute_queue(workspace_dir=target)
            logger.info("Real Desktop Worker Queue Results: %s", queue_results)

            p_name = build_result.get("project_name", project_name or "ai_project")
            scaffold_success = build_result.get("success", True)
            dur = build_result.get("duration_seconds", 0.0)
            contract = build_result.get("contract")

            # Evaluate real worker queue task completion outcomes
            tasks_failed = [tid for tid, state in queue_results.items() if state == TaskProgressState.FAILED]
            tasks_succeeded = [tid for tid, state in queue_results.items() if state == TaskProgressState.COMPLETED]
            total_queue_tasks = len(queue_results)

            if not scaffold_success:
                final_status = "failed"
                err_msg = build_result.get("error", "Scaffolding phase failed")
            elif tasks_failed and tasks_succeeded:
                final_status = "partial"
                err_msg = f"{len(tasks_failed)}/{total_queue_tasks} tasks did not complete ({', '.join(tasks_failed)})"
            elif tasks_failed and not tasks_succeeded:
                final_status = "failed"
                err_msg = f"{len(tasks_failed)}/{total_queue_tasks} tasks failed ({', '.join(tasks_failed)})"
            elif total_queue_tasks > 0 and len(tasks_succeeded) == total_queue_tasks:
                final_status = "completed"
                err_msg = None
            else:
                final_status = "completed" if scaffold_success else "failed"
                err_msg = None if final_status == "completed" else "Pipeline failed"

            # Step 3: Record Contract, Timeline, and Memory
            if contract:
                self.contract_mgr.create_contract(
                    project_name=p_name,
                    vision=getattr(contract, "vision", str(contract)),
                    requirements=getattr(contract, "requirements", []),
                )

            # Record in ProjectMemory
            self.project_memory.save_history(
                session_id=session.session_id,
                entries=[
                    {
                        "action": "project_build",
                        "status": final_status,
                        "duration_seconds": dur,
                        "idea": idea,
                    }
                ],
            )
            self.project_memory.append_timeline_entry(
                {
                    "event_type": f"project_{final_status}",
                    "summary": f"Project {p_name} execution status: {final_status}.",
                }
            )

            duration = time.time() - start_time
            self._emit_event(f"project.flow.{final_status}", {"project_name": p_name, "duration": duration, "failed_tasks": tasks_failed})

            return FlowExecutionRecord(
                project_name=p_name,
                idea_description=idea,
                phase=final_status if final_status != "completed" else "completed",
                build_result=build_result,
                duration_seconds=duration,
                status=final_status,
                error=err_msg,
                failed_tasks=tasks_failed,
                succeeded_tasks=tasks_succeeded,
            )

        except Exception as exc:
            duration = time.time() - start_time
            logger.error("Project flow execution failed: %s", exc, exc_info=True)
            self._emit_event("project.flow.failed", {"error": str(exc), "duration": duration})
            return FlowExecutionRecord(
                project_name=project_name or "unknown",
                idea_description=idea,
                phase="failed",
                duration_seconds=duration,
                status="failed",
                error=str(exc),
            )

    def _emit_event(self, event_type: str, data: Dict[str, Any]) -> None:
        if self.event_bus:
            try:
                self.event_bus.publish(Event(type=event_type, data=data))
            except Exception:
                pass
